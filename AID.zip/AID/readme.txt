Hello please run these commands:
sudo chmod +x init.AID
sudo ./init.AID
