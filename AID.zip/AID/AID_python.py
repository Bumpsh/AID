
print ('this is a AID (active interface design)')
print ('this A.I.D is all open source and you can bend it however you want')
print ('feel free to customize every module and even add new ones!')